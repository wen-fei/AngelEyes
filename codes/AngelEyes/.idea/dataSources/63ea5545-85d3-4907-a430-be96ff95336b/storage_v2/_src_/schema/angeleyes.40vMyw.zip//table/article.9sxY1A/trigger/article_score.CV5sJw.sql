CREATE TRIGGER article_score
  AFTER INSERT
  ON article
  FOR EACH ROW
  BEGIN
    INSERT INTO article_scores
    SET article_scores_id = new.article_id, article_scores = 0;
    UPDATE module
    SET module_article_count = module_article_count + 1
    WHERE module_id = new.article_module_id;
  END;

