CREATE TRIGGER collcetUpdateToArticle
AFTER INSERT ON article_collect
FOR EACH ROW
  BEGIN
  UPDATE article SET article_collect_counts = article_collect_counts + 1 WHERE article_id = new.aid;
  UPDATE article SET article_good_counts = article_good_counts + 1 WHERE article_id = new.aid;
  UPDATE article SET article_notgood_counts = article_notgood_counts + 1 WHERE article_id = new.aid;
  UPDATE article SET article_share_counts = article_share_counts + 1 WHERE article_id = new.aid;

END;
